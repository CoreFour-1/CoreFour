document.addEventListener('DOMContentLoaded', () => {
  // ---------------- Initialize map ----------------
  const map = L.map('map').setView([0, 0], 2);

  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    maxZoom: 19
  }).addTo(map);

  // ---------------- Satellites ----------------
  const satellites = {
    ISS: { 
      name: "ISS", 
      color: "#00f0ff", 
      iconUrl: "https://png.pngtree.com/png-vector/20221023/ourmid/pngtree-iss-international-space-station-mission-png-image_6343630.png", 
      coords: [0, 0], 
      trailCoords: [] 
    },
    Hubble: { 
      name: "Hubble", 
      color: "#ffd166", 
      iconUrl: "https://png.pngtree.com/png-clipart/20201027/ourlarge/pngtree-cartoon-blue-satellite-space-png-image_2374022.jpg", 
      coords: [10, 10], 
      trailCoords: [] 
    },
    Terra: { 
      name: "Terra", 
      color: "#7be495", 
      iconUrl: "https://png.pngtree.com/png-vector/20210214/ourmid/pngtree-cartoon-satellite-png-image_2920681.jpg", 
      coords: [-10, -10], 
      trailCoords: [] 
    },
    Sentinel: { 
      name: "Sentinel", 
      color: "#ff6b6b", 
      iconUrl: "https://png.pngtree.com/png-clipart/20210313/ourmid/pngtree-color-small-cartoon-satellite-clipart-png-image_3039795.png", 
      coords: [20, 20], 
      trailCoords: [] 
    }
  };

  // ---------------- Create markers & trails ----------------
  Object.keys(satellites).forEach(key => {
    const sat = satellites[key];
    const customIcon = L.icon({ 
      iconUrl: sat.iconUrl, 
      iconSize: [45, 45], 
      iconAnchor: [22, 22], 
      popupAnchor: [0, -10] 
    });
    sat.marker = L.marker(sat.coords, { icon: customIcon }).addTo(map);
    sat.trail = L.polyline(sat.trailCoords, { color: sat.color, weight: 3, opacity: 0.9 }).addTo(map);
    sat.marker.bindPopup(`<b>${sat.name}</b>`).on('mouseover', function(){ 
      this.openPopup(); 
    }).on('mouseout', function(){ 
      this.closePopup(); 
    });
  });

  // ---------------- Facts ----------------
  const facts = {
    ISS:{ brief:"Live: ISS — real-time position.", mission:"International Space Station is a habitable modular space station.", orbit:"Approx 420 km altitude, orbits Earth every ~90 min.", fun:"Astronauts witness 16 sunrises and sunsets each day.", launch:"First launched in 1998, continuously inhabited since 2000.", purpose:"Scientific research, tech demos, international cooperation.", news:"https://www.nasa.gov/mission_pages/station/main/index.html" },
    Hubble:{ brief:"Hubble: powerful space telescope.", mission:"Observes deep space in visible, UV, and near-IR.", orbit:"LEO ~547 km, orbit period ~96 min.", fun:"Captured iconic images like Pillars of Creation.", launch:"Launched April 24, 1990.", purpose:"Astronomical observations: galaxies, nebulae, exoplanets.", news:"https://www.nasa.gov/mission_pages/hubble/main/index.html" },
    Terra:{ brief:"Terra: Earth observation satellite.", mission:"Studies atmosphere, land, energy balance for climate.", orbit:"Sun-synchronous orbit, ~705 km altitude.", fun:"Tracks vegetation, fires, snow & ice, aerosols.", launch:"Launched Dec 18, 1999.", purpose:"Long-term climate and Earth system observations.", news:"https://terra.nasa.gov/" },
    Sentinel:{ brief:"Sentinel-2: Earth observation satellite.", mission:"Captures high-res imagery for environment monitoring.", orbit:"Sun-synchronous orbit, polar inclination.", fun:"Used for vegetation, soil, water monitoring.", launch:"Launched June 23, 2015.", purpose:"Supports Copernicus program for Earth observation.", news:"https://sentinel.esa.int/web/sentinel/home" }
  };

  // ---------------- UI Elements ----------------
  const satButtons = document.querySelectorAll('.satBtn');
  const factButtons = document.querySelectorAll('.factBtn');
  const satNameEl = document.getElementById('satName');
  const briefEl = document.getElementById('brief');
  const detailText = document.getElementById('detailText');

  let selected = "ISS";

  function selectSatellite(name){
    selected = name;
    satButtons.forEach(b => b.classList.toggle('active', b.dataset.sat===name));
    satNameEl.textContent = name;
    briefEl.textContent = facts[name].brief;
    detailText.textContent = "Click info buttons above to see details.";
  }

  satButtons.forEach(btn => btn.addEventListener('click', ()=> selectSatellite(btn.dataset.sat)));
  factButtons.forEach(btn => {
    btn.addEventListener('click', ()=>{
      const kind = btn.dataset.fact;
      if(kind==='news'){ window.open(facts[selected].news,'_blank'); }
      else{ detailText.textContent = facts[selected][kind] || "No info available."; }
    });
  });

  selectSatellite(selected);

  // ---------------- Day/Night Overlay ----------------
  let nightLayer = null;
  function updateDayNight(){
    const now = new Date();
    const utcHours = now.getUTCHours() + now.getUTCMinutes()/60;
    const sunLon = (utcHours/24)*360 - 180;
    const antiLon = (sunLon+180)%360;
    const antiLonNormalized = antiLon>180 ? antiLon-360 : antiLon;
    if(nightLayer) map.removeLayer(nightLayer);
    nightLayer = L.circle([0, antiLonNormalized], { radius:20000000, color:'#000', fillColor:'#000', fillOpacity:0.35, interactive:false }).addTo(map);
  }
  updateDayNight();
  setInterval(updateDayNight,60000);

  // ---------------- Update Satellite Positions ----------------
  async function updatePositions(){
    const t = Date.now()/1000;

    // ISS live
    try{
      const res = await fetch('https://api.wheretheiss.at/v1/satellites/25544');
      if(res.ok){
        const j = await res.json();
        satellites.ISS.coords = [j.latitude, j.longitude];
      }
    }catch(e){
      const tt = t/60;
      satellites.ISS.coords = [Math.sin(tt)*20,(tt*2)%360-180];
    }

    // Simulated positions
    const ph = (t%(96*60))/(96*60); satellites.Hubble.coords=[Math.sin(ph*2*Math.PI)*28+10,((ph*360)-180)%360];
    const ph2= (t%(98*60))/(98*60); satellites.Terra.coords=[Math.cos(ph2*2*Math.PI)*55,((ph2*360*1.1)-180)%360];
    const ph3= (t%(100*60))/(100*60); satellites.Sentinel.coords=[Math.sin(ph3*2*Math.PI)*50,((ph3*360*1.05)-180)%360];

    Object.keys(satellites).forEach(key=>{
      const sat = satellites[key];
      const [lat,lon] = sat.coords;
      sat.marker.setLatLng([lat,lon]);
      sat.trailCoords.push([lat,lon]);
      if(sat.trailCoords.length>200) sat.trailCoords.shift();
      sat.trail.setLatLngs(sat.trailCoords);
    });

    map.panTo(satellites[selected].coords, {animate:true, duration:0.9});
  }

  updatePositions();
  setInterval(updatePositions,2000);
});
